var a="<ul>";
a+="<a href=\"index.php\"><li id = \"menu_links\">Home</li></a>";
a+="<a href=\"Blog.php\" onclick=\"check(0)\"><li id = \"menu_links\">VN's</li></a>";
a+="<a href=\"Blog.php\" onclick=\"check(1)\"><li id = \"menu_links\">FaQ</li></a>";
a+="<a href=\"index.php\"><li id = \"menu_links\">Contact us</li></a>";
a+="</ul><br>";
document.write(a);
