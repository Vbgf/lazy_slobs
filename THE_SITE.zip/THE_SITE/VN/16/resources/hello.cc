#include <iostream>
using namespace std;

int main() {

//	std::cout << "Hello world!" <<std::endl;
	cout << "Hello world!" << endl;
	return 0;
}

