#include <iostream>
using namespace std;

void wrong() {
}



int main() {
	cout << wrong() << endl;
	return 0;
}
