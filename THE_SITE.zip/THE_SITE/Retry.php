<html>
	<head>
		<title>BLOG</title>
		<link rel="stylesheet" type="text/css" href="../mystyle.css">
	</head>
	<body>
		<marquee><font color="red" font face="Comic Sans MS" size="10">WELCOME TO IOSYF"S PLACE DOT COM!!!!!!!!!!!!</font></marquee>
		<br>
		<ul>
			<li><a href="../Iosyf's_website.html">Home</a></li>
			<li>Lists
				<ul>
					<li> <a href="../Anime_list.php">Anime</a></li>
					<li> <a href="../Manga_list.php">Manga</a></li>
					<li> <a href="../Searching.php">Searching for ... </a></li>
				</ul>
			</li>
			<li>Products
				<ul>
					<li> <a href="../Anime_list.php">Code</a></li>
					<li> <a href="../Anime_list.php">Not Code</a></li>
				</ul>
			</li>
			<li> <a href="../Blog.php">Blog</a></li>
		</ul>
		<div id = "MAIN">
			<br>
			<p style = "color: red; margin-top: 40px; position:relative; font-size:30px;">
				Wrong Username or Password
			</p>
			<br>
			<form method="post">
				<pre>User name</pre><input type="text" value="User name here" name="a"><br>
				<pre>Password</pre><input type="password" value="Password here" name="b"><br><br>
				<input type="submit" value="Login" onclick=action="../Login.php"><input  type="submit"  value = "Register" onclick=action="../Register.php">
			</form>
			<br>
		</div>
		<div id = "MAIN2"></div>
	</body>
</html>
