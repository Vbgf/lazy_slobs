<?php
	session_start();
	$_SESSION["page"]=page_num;
	//header("Refresh");
?>
